package com.study.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex99Sample2Application {

	public static void main(String[] args) {
		SpringApplication.run(Ex99Sample2Application.class, args);
	}

}
