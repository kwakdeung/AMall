package com.study.springboot.dto;

import lombok.Data;

@Data
public class SaleDto {
	private String mid;
	private int pnum;
}
