package com.study.springboot.dto;

import lombok.Data;

@Data
public class CartDto {
	private String mid;
	private int pnum;
	private int ccnt;
}
